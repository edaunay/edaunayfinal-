package com.example.hastanerandevu.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Policlinic(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val clinicName: String,
    val doctorName: String
) {
}