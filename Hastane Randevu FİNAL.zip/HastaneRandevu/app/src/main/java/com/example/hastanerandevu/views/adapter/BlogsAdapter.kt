package com.example.hastanerandevu.views.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.BlogViewHolderBinding
import com.example.hastanerandevu.databinding.HospitalViewHolderBinding
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.model.Hospital

class BlogsAdapter : RecyclerView.Adapter<BlogsAdapter.BlogsViewHolder>() {

    private val blogList = arrayListOf<Blogs>()

    fun setBlogList(list: List<Blogs>) {
        blogList.clear()
        blogList.addAll(list)
        notifyDataSetChanged()
    }

    class BlogsViewHolder(val binding: BlogViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(blog: Blogs) {
            binding.textViewBlogTitle.text = blog.blogTitle
            binding.textViewBlogDetail.text = blog.blogDetail
            binding.buttonDoctor.text = blog.blogDoctor
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BlogsViewHolder {
        return BlogsViewHolder(
            BlogViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    override fun onBindViewHolder(holder: BlogsViewHolder, position: Int) {
        val blog = blogList[position]

        holder.bind(blog)


    }

    override fun getItemCount(): Int {
        return blogList.size
    }


}