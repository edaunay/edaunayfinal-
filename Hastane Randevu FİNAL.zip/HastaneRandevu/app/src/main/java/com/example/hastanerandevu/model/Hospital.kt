package com.example.hastanerandevu.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize


@Parcelize
@Entity
data class Hospital(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val hospitalName: String,
    val hospitalCity: String
): Parcelable
