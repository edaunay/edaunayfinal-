package com.example.hastanerandevu.utils

import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import com.example.hastanerandevu.R
import com.example.hastanerandevu.model.User
import com.google.gson.Gson


class SharedPrefUtils(context: Context) {
    private val context: Context = context
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE)
    private val editor: Editor = sharedPreferences.edit()
    fun setInt(key: String?, value: Int) {
        editor.putInt(key, value)
        editor.apply()
    }

    fun setString(key: String?, value: String?) {
        editor.putString(key, value)
        editor.apply()
    }

    fun setBoolean(key: String?, value: Boolean) {
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getBoolean(key: String?, def: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, def)
    }

    fun getInt(key: String?, def: Int): Int {
        return sharedPreferences.getInt(key, def)
    }

    fun getString(key: String?, def: String?): String? {
        return sharedPreferences.getString(key, def)
    }

    fun setUser(user: User?) {
        val gson = Gson()
        val json = gson.toJson(user)
        editor.putString("user",json)
        editor.apply()
    }

    fun getUser(): User? {
        val gson = Gson()
        val json = sharedPreferences.getString("user", "")
        return gson.fromJson(json, User::class.java)
    }

    var isRegister: Boolean
        get() = sharedPreferences.getBoolean("isRegister", false)
        set(value) {
            editor.putBoolean("isRegister", value)
            editor.apply()
        }







}