package com.example.hastanerandevu.views.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.HospitalViewHolderBinding
import com.example.hastanerandevu.model.Hospital

class HospitalAdapter(val hospitalList: List<Hospital>) : RecyclerView.Adapter<HospitalAdapter.HospitalViewHolder>() {

    lateinit var hospitalClickListener : HospitalClickListener

    class HospitalViewHolder(val binding: HospitalViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HospitalViewHolder {
        return HospitalViewHolder(
            HospitalViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    override fun onBindViewHolder(holder: HospitalViewHolder, position: Int) {
        val hospital = hospitalList[position]

        holder.binding.textViewHospitalName.text = hospital.hospitalName
        holder.binding.textViewHospitalCity.text = hospital.hospitalCity

        holder.binding.mainLayout.setOnClickListener {
            hospitalClickListener.onClick(hospital)
        }

    }

    override fun getItemCount(): Int {
        return hospitalList.size
    }

    interface HospitalClickListener {
        fun onClick(hospital: Hospital)
    }


}