package com.example.hastanerandevu.views.fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.TextView.OnEditorActionListener
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.databinding.FragmentBlogsBinding
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.views.Utils
import com.example.hastanerandevu.views.adapter.BlogsAdapter


class BlogsFragment : Fragment() {

    private var _binding : FragmentBlogsBinding? = null
    private val binding get() = _binding!!

    private lateinit var blogsAdapter: BlogsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBlogsBinding.inflate(layoutInflater,container,false)

        initRv(Utils.getBlogList())


        binding.editTextSearch.addTextChangedListener {
            if (it!!.isNotEmpty()) {
                binding.imageViewClose.visibility = View.VISIBLE
            } else {
                initRv(Utils.getBlogList())
                binding.imageViewClose.visibility = View.INVISIBLE
            }
        }

        binding.imageViewClose.setOnClickListener {
            binding.editTextSearch.setText("")
        }

        binding.editTextSearch.setOnEditorActionListener(OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                // search
                val searchList = Utils.getBlogList().filter {
                    it.blogTitle.uppercase().contains(v.text.toString().uppercase())
                }
                initRv(searchList)
                return@OnEditorActionListener true
            }
            false
        })



        return binding.root
    }

    private fun initRv(list: List<Blogs>) {
        blogsAdapter = BlogsAdapter()
        blogsAdapter.setBlogList(list)

        binding.recyclerViewBlogs.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = blogsAdapter
        }
    }

    override fun onResume() {
        super.onResume()
        initRv(Utils.getBlogList())
    }

}