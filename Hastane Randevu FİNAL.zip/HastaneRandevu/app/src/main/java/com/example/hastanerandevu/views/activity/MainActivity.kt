package com.example.hastanerandevu.views.activity

import android.R.attr.button
import android.content.Intent
import android.os.Bundle
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityMainBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory
import com.example.hastanerandevu.views.adapter.HospitalAdapter
import com.example.hastanerandevu.views.fragment.BlogsFragment
import com.example.hastanerandevu.views.fragment.HospitalFragment
import com.example.hastanerandevu.views.fragment.PharmacyFragment


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    private lateinit var sharedPrefUtils: SharedPrefUtils

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = ContextCompat.getColor(this, R.color.color_red)

        sharedPrefUtils = SharedPrefUtils(this)


        binding.imageViewMyAppointment.setOnClickListener {
            val intent = Intent(this, MyAppointmentActivity::class.java)
            startActivity(intent)
        }

        binding.imageViewMore.setOnClickListener {
            val popupMenu = PopupMenu(this@MainActivity, it)
            popupMenu.menuInflater.inflate(R.menu.menu, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { menuItem ->
                if (menuItem.itemId == R.id.itemExit) {
                    sharedPrefUtils.setUser(null)
                    val intent = Intent(this, RegisterActivity::class.java)
                    startActivity(intent)
                    finish()
                    recreate()
                }
                true
            }
            popupMenu.show()
        }


        loadFragment(HospitalFragment())

        binding.bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.hospital -> {
                    binding.textViewHospitalName.text = "Hastaneler"
                    loadFragment(HospitalFragment())
                    true
                }

                R.id.pharmacy -> {
                    binding.textViewHospitalName.text = "Eczaneler"
                    loadFragment(PharmacyFragment())
                    true
                }

                R.id.blogs -> {
                    binding.textViewHospitalName.text = "Bloglar"
                    loadFragment(BlogsFragment())
                    true
                }

                else -> {
                    loadFragment(HospitalFragment())
                    true
                }
            }
        }


    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.container, fragment)
        transaction.commit()
    }

}