package com.example.hastanerandevu.views.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.FragmentHospitalBinding
import com.example.hastanerandevu.databinding.FragmentPharmacyBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Pharmacy
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory
import com.example.hastanerandevu.views.activity.PoliclinicSelectActivity
import com.example.hastanerandevu.views.adapter.HospitalAdapter
import com.example.hastanerandevu.views.adapter.PharmacyAdapter


class PharmacyFragment : Fragment() {

    private var _binding : FragmentPharmacyBinding? = null
    private val binding get() = _binding!!

    lateinit var mainViewModel: MainViewModel

    private lateinit var pharmacyAdapter: PharmacyAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPharmacyBinding.inflate(layoutInflater,container,false)

        val mainRepository = MainRepository(AppDatabase(requireContext()))
        val viewModelProviderFactory = MainViewModelFactory(requireActivity().application,mainRepository)
        mainViewModel = ViewModelProvider(this,viewModelProviderFactory)[MainViewModel::class.java]

        pharmacyAdapter = PharmacyAdapter()

        initRv()



        return binding.root
    }

    private fun initRv() {

        pharmacyAdapter.setPharmacyList(mainViewModel.getPharmacy())

        binding.recyclerViewPharmacy.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = pharmacyAdapter
        }

    }




}