package com.example.hastanerandevu.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.User

@Dao
interface UserDao {

    @Query("SELECT * FROM user")
    fun getUser(): List<User>

    @Query("select * from user where tcNo= :tcNo and password= :password")
    fun login(tcNo: Long, password: String): LiveData<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun registerUser(user: User)


}