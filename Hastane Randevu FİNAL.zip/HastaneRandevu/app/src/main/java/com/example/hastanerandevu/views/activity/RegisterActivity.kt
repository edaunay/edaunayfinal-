package com.example.hastanerandevu.views.activity

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityRegisterBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Pharmacy
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.model.User
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory

class RegisterActivity : AppCompatActivity() {


    private lateinit var binding: ActivityRegisterBinding

    private lateinit var mainViewModel: MainViewModel

    private lateinit var sharedPrefUtils: SharedPrefUtils

    var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPrefUtils = SharedPrefUtils(this)

        val mainRepository = MainRepository(AppDatabase(this))
        val viewModelProviderFactory = MainViewModelFactory(application,mainRepository)

        mainViewModel = ViewModelProvider(this,viewModelProviderFactory)[MainViewModel::class.java]

        addHospitalAndPoliclinic()
        addPharmacy()

        if (sharedPrefUtils.getUser() != null) {
            goToHome()
        } else {
            mediaPlayer = MediaPlayer.create(this,R.raw.giris)
            mediaPlayer?.start()
        }


        binding.textViewGoLogin.setOnClickListener {
            goToLogin()
        }

        binding.buttonRegister.setOnClickListener {
            val tcNo = binding.editTextTc.text.toString().toLong()
            val nameAndSurname = binding.editTextNameAndSurname.text.toString()
            val password = binding.editTextPassword.text.toString()

            val user = User(tcNo,nameAndSurname, password)

            mainViewModel.registerUser(user)
            sharedPrefUtils.setUser(user)
            sharedPrefUtils.isRegister = true
            goToHome()

        }


    }

    private fun addPharmacy() {
        mainViewModel.addPharmacy(Pharmacy(0,"Nilay Eczanesi","İstanbul/Arnavutköy","Anadolu, Gaziosmanpaşa Cd. No:42/A, 34275"))
        mainViewModel.addPharmacy(Pharmacy(1,"Evrim Eczanesi","İstanbul/Ataşehir","Mustafa Kemal, 3096. Sk., 34707 "))
        mainViewModel.addPharmacy(Pharmacy(2,"Şifa Eczanesi","İstanbul/Avcılar","Reşit Paşa Cd. No:109, 34315"))
        mainViewModel.addPharmacy(Pharmacy(3,"Cihangir Eczanesi","İstanbul/Beyoğlu","Katip Mustafa Çelebi, CİHANGİR ECZANESİ, Sıraselviler Cd. NO:40/A, 34433"))
        mainViewModel.addPharmacy(Pharmacy(4,"Eylül Eczanesi","Ankara/Etimesgut","Şehit Osman Avcı, 2641. Sk., 06820"))
        mainViewModel.addPharmacy(Pharmacy(5,"Akınsoy Eczanesi","Ankara/Keçiören","Etlik, Altıyol Sk. no:10/A, 06010"))
        mainViewModel.addPharmacy(Pharmacy(6,"Büşra Eczanesi","Ankara/Mamak","Akdere, Kutlu Mah, Dereboyu Cd. No:55 D:C, 06630"))
        mainViewModel.addPharmacy(Pharmacy(7,"Önem Eczanesi","İzmir/Bayraklı","Mansuroğlu, 283/12. Sk. No:10/A, 35535"))
        mainViewModel.addPharmacy(Pharmacy(8,"Yeşil Eczanesi","İzmir/Bornova","Kazımdirik, Ankara Cd. Yanyolu No:237 D:1B, 35040"))
        mainViewModel.addPharmacy(Pharmacy(9,"Yeni Emre Eczanesi","İzmir/Buca"," Kozağaç, Gazeteci Yazar İsmail Sivri Blv No:126/A, 35390"))
        mainViewModel.addPharmacy(Pharmacy(10,"Sarnıç Eczanesi","İzmir/Gaziemir","Menderes, Büyük Menderes Cd. No:80, 35410"))
        mainViewModel.addPharmacy(Pharmacy(11,"Bulvar Eczanesi","İzmir/Karşıyaka","Bahriye Üçok, 35560 "))
        mainViewModel.addPharmacy(Pharmacy(12,"Limon Eczanesi","Bursa/İnegöl","Edep Ali Caddesi, Anafartalar Cd. No:1A, 16400"))
        mainViewModel.addPharmacy(Pharmacy(13,"Gümüş Eczanesi","Bursa/Mudanya","Ömerbey, Pınar Sk. Pk:16940, 16940"))
        mainViewModel.addPharmacy(Pharmacy(14,"Demet Eczanesi","Antalya/Finike","Yeni, 07740"))
        mainViewModel.addPharmacy(Pharmacy(15,"Kaş Eczanesi","Antalya/Kaş","Andifli, Hastane Cad. No:15, 07580 "))
        mainViewModel.addPharmacy(Pharmacy(16,"Toker Eczanesi","Antalya/Kepez","Zafer, Mehmet Akif Cd. 107 A, 07025 "))
        mainViewModel.addPharmacy(Pharmacy(17,"Soytürk Eczanesi","Antalya/Konyaaltı","Altınkum mah. Çamlık Cad.Ayfer Apt. 27/B Özel Olimpos Hastanesi karşısı, 07070"))
    }

    private fun addHospitalAndPoliclinic() {
        mainViewModel.addHospital(Hospital(1,"Antalya Eğitim ve Araştırma Hastanesi","Antalya"))
        mainViewModel.addHospital(Hospital(2,"AYDIN ATATÜRK DEVLET HASTANESİ","Aydın"))
        mainViewModel.addHospital(Hospital(3,"Marmara Üniversitesi Pendik Eğitim ve Araştırma Hastanesi","İstanbul"))
        mainViewModel.addHospital(Hospital(4,"Karşıyaka Devlet Hastanesi","İzmir"))
        mainViewModel.addHospital(Hospital(5,"Ankara Eğitim ve Araştırma Hastanesi","Ankara"))
        mainViewModel.addHospital(Hospital(6,"Denizli Devlet Hastanesi","Denizli"))
        mainViewModel.addHospital(Hospital(7,"Burdur Devlet Hastanesi","Burdur"))
        mainViewModel.addHospital(Hospital(8,"Balıkesir Devlet Hastanesi","Balıkesir"))
        mainViewModel.addHospital(Hospital(9,"19 Mayıs Devlet Hastanesi","Samsun"))
        mainViewModel.addHospital(Hospital(10,"Fatsa Devlet Hastanesi","Ordu"))

        mainViewModel.addPoliclinic(Policlinic(1,"İç Hastalıkları (Dahiliye)","AYŞEGÜL ZÜMRÜTDAL"))
        mainViewModel.addPoliclinic(Policlinic(2,"Amatem (Alkol ve Madde Bağımlılığı)","CEMAL KARAYAZI"))
        mainViewModel.addPoliclinic(Policlinic(3,"Beyin ve Sinir Cerrahisi","BEHRAM KAYA"))
        mainViewModel.addPoliclinic(Policlinic(4,"Kardiyoloji","RANA MUTTALİP"))
        mainViewModel.addPoliclinic(Policlinic(5,"Nöroloji","KERİM NURİHALİÇİ"))
        mainViewModel.addPoliclinic(Policlinic(6,"Ruh Sağlığı ve Hastalıkları (Psikiyatri)","İREM YALUĞ ULUBİL"))
    }

    private fun goToLogin() {
        val intent = Intent(this,LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun goToHome() {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}