package com.example.hastanerandevu.views.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.FragmentHospitalBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory
import com.example.hastanerandevu.views.activity.PoliclinicSelectActivity
import com.example.hastanerandevu.views.adapter.HospitalAdapter


class HospitalFragment : Fragment() {

    private var _binding : FragmentHospitalBinding? = null
    private val binding get() = _binding!!

    private lateinit var hospitalAdapter: HospitalAdapter

    lateinit var mainViewModel: MainViewModel


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHospitalBinding.inflate(layoutInflater,container,false)

        val mainRepository = MainRepository(AppDatabase(requireContext()))
        val viewModelProviderFactory = MainViewModelFactory(requireActivity().application,mainRepository)
        mainViewModel = ViewModelProvider(this,viewModelProviderFactory)[MainViewModel::class.java]

        initRv()


        return binding.root
    }

    private fun initRv() {
        hospitalAdapter = HospitalAdapter(mainViewModel.getHospital())

        hospitalAdapter.hospitalClickListener = object : HospitalAdapter.HospitalClickListener {
            override fun onClick(hospital: Hospital) {
                val policlinicSelectIntent = Intent(requireContext(), PoliclinicSelectActivity::class.java)
                policlinicSelectIntent.putExtra("hospital",hospital)
                startActivity(policlinicSelectIntent)
            }

        }
        binding.recyclerViewHospital.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = hospitalAdapter
        }
    }

    override fun onResume() {
        super.onResume()
        initRv()
    }

}