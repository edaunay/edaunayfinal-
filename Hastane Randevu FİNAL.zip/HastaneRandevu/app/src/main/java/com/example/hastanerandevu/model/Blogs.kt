package com.example.hastanerandevu.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Blogs(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val blogTitle: String,
    val blogDetail: String,
    val blogDoctor: String
) {
}