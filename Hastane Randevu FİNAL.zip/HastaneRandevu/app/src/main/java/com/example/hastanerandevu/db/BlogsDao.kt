package com.example.hastanerandevu.db

import androidx.room.*
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.model.Policlinic

@Dao
interface BlogsDao {

    @Query("SELECT * FROM Blogs")
    fun getBlogs() : List<Blogs>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBlogs(blogs: Blogs)


}