package com.example.hastanerandevu.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize


@Parcelize
@Entity
data class Appointment(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val hospitalName: String,
    val hospitalCity: String,
    val clinicName: String,
    val doctorName: String,
    val tcNo: Long,
    val nameAndSurname: String,
    val date: String,
    val time: String
): Parcelable
