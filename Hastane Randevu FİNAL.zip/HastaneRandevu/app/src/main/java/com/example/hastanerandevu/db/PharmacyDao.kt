package com.example.hastanerandevu.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Pharmacy

@Dao
interface PharmacyDao {

    @Query("SELECT * FROM Pharmacy order by id DESC")
    fun getPharmacy() : List<Pharmacy>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addPharmacy(pharmacy: Pharmacy)


}