package com.example.hastanerandevu.db

import androidx.room.*
import com.example.hastanerandevu.model.Policlinic

@Dao
interface PoliclinicDao {

    @Query("SELECT * FROM Policlinic")
    fun getPoliclinic() : List<Policlinic>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addPoliclinic(policlinic: Policlinic)


}