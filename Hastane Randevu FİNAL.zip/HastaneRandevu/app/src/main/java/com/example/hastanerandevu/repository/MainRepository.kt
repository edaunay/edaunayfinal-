package com.example.hastanerandevu.repository

import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Appointment
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Pharmacy
import com.example.hastanerandevu.model.User


class MainRepository(private val db : AppDatabase) {

    suspend fun addHospital(hospital: Hospital) = db.hospitalDao().addHospital(hospital)

    fun getHospital() = db.hospitalDao().getHospital()

    suspend fun addPoliclinic(policlinic: Policlinic) = db.clinicDao().addPoliclinic(policlinic)

    fun getPoliclinic() = db.clinicDao().getPoliclinic()

    suspend fun registerUser(user: User) = db.userDao().registerUser(user)

    fun getUser() = db.userDao().getUser()

    fun loginUser(tcNo: Long,password: String) = db.userDao().login(tcNo, password)

    suspend fun addAppointment(appointment: Appointment) = db.appointmentDao().addAppointment(appointment)
    fun myAppointment(tcNo: Long) = db.appointmentDao().myAppointment(tcNo)
    fun deleteAppointment(appointment: Appointment) = db.appointmentDao().deleteAppointment(appointment)


    suspend fun addBlog(blogs: Blogs) = db.blogsDao().addBlogs(blogs)
    fun getBlogs() = db.blogsDao().getBlogs()

    suspend fun addPharmacy(pharmacy: Pharmacy) = db.pharmacyDao().addPharmacy(pharmacy)
    fun getPharmacy() = db.pharmacyDao().getPharmacy()


}