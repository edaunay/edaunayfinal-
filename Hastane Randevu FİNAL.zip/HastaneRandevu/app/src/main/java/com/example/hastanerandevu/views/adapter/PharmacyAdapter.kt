package com.example.hastanerandevu.views.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.databinding.PharmacyViewHolderBinding
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Pharmacy

class PharmacyAdapter() : RecyclerView.Adapter<PharmacyAdapter.HospitalViewHolder>() {

    private val pharmacyList = arrayListOf<Pharmacy>()

    fun setPharmacyList(list: List<Pharmacy>) {
        pharmacyList.clear()
        pharmacyList.addAll(list)
        notifyDataSetChanged()
    }

    class HospitalViewHolder(val binding: PharmacyViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HospitalViewHolder {
        return HospitalViewHolder(
            PharmacyViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: HospitalViewHolder, position: Int) {
        val pharmacy = pharmacyList[position]

        holder.binding.textViewPharmacyName.text = pharmacy.pharmacyName
        holder.binding.textViewPharmacyCity.text = pharmacy.pharmacyCity
        holder.binding.textViewPharmacyAddress.text = "Adres: ${pharmacy.pharmacyAddress}"


    }

    override fun getItemCount(): Int {
        return pharmacyList.size
    }

    interface PharmacyClickListener {
        fun onClick(pharmacy: Pharmacy)
    }


}