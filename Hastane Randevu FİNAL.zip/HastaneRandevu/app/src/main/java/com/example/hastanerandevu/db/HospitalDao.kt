package com.example.hastanerandevu.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.hastanerandevu.model.Hospital

@Dao
interface HospitalDao {

    @Query("SELECT * FROM Hospital order by id DESC")
    fun getHospital() : List<Hospital>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addHospital(hospital: Hospital)


}